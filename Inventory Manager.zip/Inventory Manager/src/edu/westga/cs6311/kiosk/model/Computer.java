package edu.westga.cs6311.kiosk.model;

import java.text.DecimalFormat;

/**
 * Computer builds an inventory list of computers detailing their Sku, price and
 * the amount on hand
 * 
 * @author Drew Coleman
 * @version 11/30/2017
 *
 */
public class Computer {
	private String computerSKU;
	private Double price;
	private int inventory;

	/**
	 * This is the constructor it builds the a default computer object with no name
	 * price or inventory value
	 */
	public Computer() {
		this.computerSKU = "";
		this.price = 0.00;
		this.inventory = 0;
	}

	/**
	 * This is the constructor which accepts imported value for the computer object
	 * 
	 * @param computerSKU
	 *            The computers SKU
	 * @param price
	 *            price of the new computer
	 * @param userInventory
	 *            how many of the new computers there are
	 */
	public Computer(String computerSKU, Double price, int userInventory) {
		if (computerSKU == null) {
			computerSKU = "";
		}
		if (price < 0 || price > 10000) {
			price = 0.0;
		}
		if (userInventory < 0 || userInventory > 1000) {
			userInventory = 0;
		}

		this.computerSKU = computerSKU;
		this.price = price;
		this.inventory = userInventory;
	}

	/**
	 * Getter for computerSKU
	 * 
	 * @return computerSKU which is a String of the Computer SKU
	 */
	public String getSku() {
		return this.computerSKU;
	}

	/**
	 * Getter for Price
	 * 
	 * @return this.price which is the cost of the computer
	 */
	public Double getPrice() {
		return this.price;
	}

	/**
	 * getter for Inventory
	 * 
	 * @return this.inventory which is the number of computers on hand
	 */
	public int getInventory() {
		return this.inventory;
	}

	/**
	 * THIS METHOD MIGHT NEED TO BE CHANGED AND ONLY CHANGE NOT TEST NUMBER OF
	 * COMPUTERS IN STOCK This method allows the inventory Int to be reset
	 * 
	 * @param newInventory
	 *            the new inventory value
	 */
	public void setInventory(int newInventory) {
		if (newInventory >= 0) {
			this.inventory = newInventory;
		}
	}

	/**
	 * This method accepts number of items being purchased it test to insure that
	 * there is a high enough inventory
	 * 
	 * @param itemsPurchased
	 *            removes the amount of purchased items from the inventory
	 */
	public void purchase(int itemsPurchased) {
		if (itemsPurchased > 0 && this.inventory >= itemsPurchased) {
			this.inventory = this.inventory - itemsPurchased;
		}
		return;
	}

	/**
	 * This method places the computer value into a formated String
	 * 
	 * @return skuInventoryValue - the sku price and inventory of the computer
	 */
	public String toString() {
		DecimalFormat format = new DecimalFormat("0.00");
		String correctlyFormattedPrice = format.format(this.price);
		String computerString = "";
		computerString += String.format("%-6.6s", this.computerSKU) + " $";
		computerString += String.format("%7.7s", correctlyFormattedPrice);
		computerString += " In Stock: ";
		computerString += String.format("%3.3s", this.inventory);

		return computerString;

	}
}
