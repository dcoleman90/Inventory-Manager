package edu.westga.cs6311.kiosk.model;

import java.util.ArrayList;

/**
 * This is the class Customer It sets up name, amount to spend, and what in
 * their cart
 * 
 * @author Drew Coleman
 * @version 12/01/17
 */
public class Customer {
	private String name;
	private double wallet;
	private ArrayList<Computer> shoppingCart;

	/**
	 * This is the constructor
	 * @param customerName - name of customer
	 * @param wallet - amount customer brought to spend
	 */
	public Customer(String customerName, double wallet) {
		this.name = customerName;
		this.wallet = wallet;
		this.shoppingCart = new ArrayList<Computer>();
	}

	/**
	 * Accessor for the name
	 * 
	 * @return customer name
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * accessor for wallet
	 * 
	 * @return amount left in customer wallet
	 */
	public double checkWallet() {
		this.wallet = Math.round(this.wallet * 100);
		this.wallet = this.wallet / 100;
		return this.wallet;
	}

	/**
	 * This method checks the shopping cart for products
	 * 
	 * @return a message say what or if there is any product in the cart
	 */
	public String getCart() {
        if (this.shoppingCart.isEmpty()) {
			return "No Items \n\n";
		}
		String cartInventory = "\t";
        for (Computer listOfComputers : this.shoppingCart) {
			cartInventory += listOfComputers.toString() + "\n\t";
		}
        cartInventory += "\n";
		return cartInventory;
	}

	/**
	 * This method checks the amount in wallet verse the desired purchase
	 * 
	 * @param possiblePurchase
	 *            computer object to buy
	 * @param amount
	 *            amount of computer objects
	 * @return true if the wallet has enough money to cover it
	 */
	public boolean enoughMoneyToBuy(Computer possiblePurchase, int amount) {
		return this.wallet > (possiblePurchase.getPrice() * amount);
	}

	/**
	 * This method removes the cost from wallet and adds the appropriate amount of
	 * computers to the cart
	 * 
	 * @param custComp
	 *            the computer to be bought
	 * @param quantity
	 *            the amount of computers to purchase
	 */
	public void addComputer(Computer custComp, int quantity) {
        Computer addToCart = new Computer(custComp.getSku(), custComp.getPrice(), quantity);
        if (this.wallet >= (custComp.getPrice() * quantity) && quantity <= custComp.getInventory()) {
            this.wallet = this.wallet - (custComp.getPrice() * quantity);
            this.shoppingCart.add(addToCart);
            custComp.purchase(quantity);
        }
	}

	/**
	 * This method removes all items from the shopping cart
	 */
	public void completePurchase() {
		this.shoppingCart.clear();
	}
}
