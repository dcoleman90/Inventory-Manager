package edu.westga.cs6311.kiosk.model;

import java.util.ArrayList;

/**
 * This is the InventoryManager class it manages an array of Computer classes
 * 
 * @author Drew Coleman
 * @version 12/01/2017
 *
 */
public class InventoryManager {
	private ArrayList<Computer> computersInStore;

	/**
	 * This is the constructor which builds an ArrayList of Computer objects
	 */
	public InventoryManager() {
		this.computersInStore = new ArrayList<Computer>();
	}

	/**
	 * This method adds two computers into the the array by calling the Computer's
	 * constructor
	 */
	public void startStore() {
		Computer newHP = new Computer("HP1234", 699.99, 15);
		Computer newDell = new Computer("DL333", 1349.28, 120);
		this.computersInStore.add(newHP);
		this.computersInStore.add(newDell);
	}

	/**
	 * This method searches the SKU for computer
	 *
	 * @param computerSKU
	 *            is the SKU
	 * @return the computer found matching the SKU
	 */
	public Computer findComputer(String computerSKU) {
		if (computerSKU == null) {
			return null;
		}

		for (Computer computerSearch : this.computersInStore) {
			if (computerSearch.getSku().equalsIgnoreCase(computerSKU)) {
				return computerSearch;
			}
		}
		return null;
	}

	/**
	 * this method adds computers to the array
	 *
	 * @param addSKU
	 *            sku of the new computer
	 * @param price
	 *            price of the new computer
	 * @param inventory
	 *            inventory of the new computer
	 */
	public void addComputer(String addSKU, Double price, int inventory) {
		Computer newComputer = new Computer(addSKU, price, inventory);
		this.computersInStore.add(newComputer);
	}

	/**
	 * Finds the least expensive computer and returns it as a String value
	 * 
	 * @return a string of the cheapest computer
	 */
	public String getLeastExpensive() {
		double minValue = Integer.MAX_VALUE;
		String leastExpensive = "";
		for (Computer counterComputer : this.computersInStore) {
			if (counterComputer.getPrice() < minValue) {
				minValue = counterComputer.getPrice();
				leastExpensive = counterComputer.toString();
			}
		}
		return leastExpensive;
	}

	/**
	 * Finds the most expensive computer and returns it as a String value
	 * 
	 * @return computer object(to string) with the highest value
	 */
	public String getMostExpensive() {
		double maxValue = Integer.MIN_VALUE;
		String mostExpensive = "";
		for (Computer counterComputer : this.computersInStore) {
			if (counterComputer.getPrice() > maxValue) {
				maxValue = counterComputer.getPrice();
				mostExpensive = counterComputer.toString();
			}
		}
		return mostExpensive;
	}

	/**
	 * This method totals up the inventory of the computers
	 * 
	 * @return the sum of all the Computer Inventory
	 */
	public int getTotalInStock() {
		int sum = 0;

		for (Computer totalInventory : this.computersInStore) {
			sum += totalInventory.getInventory();
		}
		return sum;
	}

	/**
	 * This method averages all the prices of computers
	 * 
	 * @return the average price of computer
	 */
	public double getAveragePrice() {
		double price = 0.0;
		if (this.computersInStore == null) {
			return 0;
		}

		for (Computer averagePrice : this.computersInStore) {
			price += averagePrice.getPrice();
		}
		return price / this.computersInStore.size();
	}

	/**
	 * This method puts the InventoryManager to String
	 * 
	 * @return a String representation of the InventoryManager
	 */
	public String toString() {
		if (this.computersInStore.isEmpty()) {
			return "Inventory is empty";
		}
		String totalInventory = "\nTotal Inventory\n";
		for (Computer listOfComputers : this.computersInStore) {
			totalInventory += listOfComputers.toString() + "\n";
		}
		return totalInventory;
	}

}
