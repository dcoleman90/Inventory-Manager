package edu.westga.cs6311.kiosk.view;

import edu.westga.cs6311.kiosk.model.InventoryManager;

import java.util.Scanner;

/**
 * This is the KioskTUI class it manages the customer and store inventory
 * 
 * @author Drew Coleman
 * @version 12/02/2017
 */
public class KioskTUI {
	private Scanner scan;
	private InventoryManager kioskInventoryManger;

	/**
	 * This is the constructor which builds by accepting InventoryManager object
	 * customerCart
	 * 
	 * @param customerCart
	 *            is the built InventoryManager object
	 */
	public KioskTUI(InventoryManager customerCart) {
		this.scan = new Scanner(System.in);
		this.kioskInventoryManger = new InventoryManager();
		if (customerCart == null) {
			return;
		} else {
			this.kioskInventoryManger = customerCart;
		}
	}

	/**
	 * this method servers as the director of the TUI It allows the user to switch
	 * between manager and customer applications
	 */
	public void runKiosk() {
		int userChoiceKiosk = 0;
		this.header();
		if (userChoiceKiosk != 3) {
			this.displayMenu();
			System.out.print("Please enter in your choice: ");
			userChoiceKiosk = Integer.parseInt(this.scan.nextLine());

			switch (userChoiceKiosk) {
				case 1:
					this.runManagerTUI();
					break;
				case 2:
					this.runCustomerTUI();
					break;
				case 3:
					this.exitMessage();
					break;
	
				default:
					this.defaultMessage();
					this.runKiosk();
					break;
			}
		}
	}

	private void displayMenu() {
		System.out.println("\t1 - Start Management App");
		System.out.println("\t2 - Start Customer App");
		System.out.println("\t3 - Exit\n");
	}

	private void runManagerTUI() {
		ManagerTUI managerTUIAPP = new ManagerTUI(this.kioskInventoryManger);
		managerTUIAPP.runManager();
	}

	private void header() {
		System.out.println("\nWelcome to the Great Purchase App\n");
	}

	private void runCustomerTUI() {
		CustomerTUI customerTUIAPP = new CustomerTUI(this.kioskInventoryManger);
		customerTUIAPP.runCustomer();
	}

	private void defaultMessage() {
		System.out.println("\nThat is not a valid option. Please try again\n");
	}

	private void exitMessage() {
		System.out.println("\nThank you for using Great Purchase App\nGoodbye");
	}
}
