package edu.westga.cs6311.kiosk.view;

import edu.westga.cs6311.kiosk.model.InventoryManager;

import java.util.Scanner;

/**
 * This is the Text User Interface to interact with the InventoryManager
 * 
 * @author Drew Coleman
 * @version 12/01/2017
 *
 */
public class ManagerTUI {
	private Scanner scan;
	private InventoryManager computerInventory;

	/**
	 * This is the constructor which accepts an InventoryManager object
	 * 
	 * @param theComputerInventory
	 *            is the Inventory manager class
	 */
	public ManagerTUI(InventoryManager theComputerInventory) {
		if (theComputerInventory == null) {
			return;
		} else {
			this.scan = new Scanner(System.in);
			this.computerInventory = theComputerInventory;
		}
	}

	/**
	 * This method runs calls the header to welcome the user then displays the menu
	 * calling other private methods as needed
	 */
	public void runManager() {
		this.header();
		this.menu();
	}

	private void header() {
		System.out.println("\nWelcome to Computer Inventory Management\n");
	}

	private void displayMenu() {
		System.out.println("\t1 - Open a new store\n" + "\t2 - Add a new Computer\n" + "\t3 - View Inventory\n"
				+ "\t4 - Quit Computer Inventory Management\n");
		System.out.print("Please enter in your selection: ");
	}

	private void menu() {
		KioskTUI returnToMenu = new KioskTUI(this.computerInventory);
		int userChoice = 0;
		do {
			this.displayMenu();
			userChoice = Integer.parseInt(this.scan.nextLine());
			switch (userChoice) {
				case 1:
					this.openNewStore();
					break;
				case 2:
					this.addNewComputer();
					break;
				case 3:
					this.currentInventory();
					break;
				case 4:
					this.exitMessage();
					returnToMenu.runKiosk();
					break;
				default:
					System.out.println("That is not a valid option. Please try again\n");
			}
		} while (userChoice != 4);
	}

	private void openNewStore() {
		this.computerInventory.startStore();
		System.out.println("\nYou Started a new Store\n");
	}

	private void addNewComputer() {
		String theSKU;
		int inventory;
		double price;

		System.out.print("\nEnter in the SKU of the new computer: ");
		theSKU = this.scan.nextLine();
		do {
			System.out.print("Enter in the amount of computers added to Inventory: ");
			inventory = Integer.parseInt(this.scan.nextLine());
		} while (inventory > 1000 || inventory <= 0);
		do {
			System.out.print("Enter in the cost of the computers: ");
			price = Double.parseDouble(this.scan.nextLine());
			price = Math.round(price * 100);
			price = (price / 100);
		} while (price > 10000 || price <= 0);
		this.computerInventory.addComputer(theSKU, price, inventory);
		System.out.print("\nYou added " + inventory + ", " + theSKU + "(s) with a price of $");
		System.out.printf("%.2f", price);
		System.out.print(" to the inventory\n\n");
	}

	private void currentInventory() {
		System.out.println(this.computerInventory.toString());

		if (this.computerInventory.getTotalInStock() != 0) {
			System.out.println("Total number of computers in Store:\t" + this.computerInventory.getTotalInStock());
			System.out.println("The most expensive computer is : \t" + this.computerInventory.getMostExpensive());
			System.out.println("The least expensive computer is: \t" + this.computerInventory.getLeastExpensive());
			System.out.print("The Average computer price is: \t\t");
			System.out.printf("%.2f", this.computerInventory.getAveragePrice());
			System.out.println("\n");
		}
	}

	private void exitMessage() {
		System.out.println("\nThank you for using Computer Inventory Management\n");
	}

}
