package edu.westga.cs6311.kiosk.view;

import edu.westga.cs6311.kiosk.model.Computer;
import edu.westga.cs6311.kiosk.model.Customer;
import edu.westga.cs6311.kiosk.model.InventoryManager;

import java.util.Scanner;

/**
 * This class is the Customer TUI class
 * 
 * @author Drew Coleman
 * @version 12/02/2017
 */
public class CustomerTUI {
	private InventoryManager shelfInventory;
	private Customer customer;
	private Scanner scan;

	/**
	 * This is the constructor
	 * 
	 * @param theShelfInventory
	 *            this is the value passed in
	 */
	public CustomerTUI(InventoryManager theShelfInventory) {
		if (theShelfInventory == null) {
			return;
		} else {
			this.shelfInventory = theShelfInventory;
        }
		this.customer = new Customer("", 0.0);
        this.scan = new Scanner(System.in);
	}

	/**
	 * This method runs the CustomerTUI calling the appropiate helpers
	 */
	public void runCustomer() {
		this.customerTUIheader();
		this.getCustomerInformation();
		this.customerMenu();
	}

	private void customerTUIheader() {
		System.out.println("\nWelcome to the Great Shopping App\n");
	}

	private void getCustomerInformation() {
		String name;
		double walletSize;
		System.out.print("Please enter in your name: ");
		name = this.scan.nextLine();
		do {
			System.out.print("Please enter in how much you are willing to spend: ");
			walletSize = Double.parseDouble(this.scan.nextLine());
			walletSize = Math.round(walletSize * 100);
			walletSize = walletSize / 100;
		} while (walletSize < 0.0);
		this.customer = new Customer(name, walletSize);
		System.out.println("\n Welcome " + name);
		this.checkCustomerWallet();
		System.out.println("");
	}

	private void customerMenu() {
		KioskTUI returnToMenu = new KioskTUI(this.shelfInventory);
		int userChoice;
		do {
			this.displayCustomerMenu();
			userChoice = Integer.parseInt(this.scan.nextLine());
			switch (userChoice) {
				case 1:
					this.currentInventory();
					break;
				case 2:
					this.addComputerToCart();
					break;
				case 3:
					this.checkCart();
					break;
				case 4:
					this.checkCustomerWallet();
					break;
				case 5:
					this.checkoutCustomer();
					break;
				case 6:
					this.exitMessage();
					returnToMenu.runKiosk();
					break;
				default:
					System.out.println("That is not a valid option. Please try again\n");
			}
		} while (userChoice != 6);
	}

	private void displayCustomerMenu() {
		System.out.println("\nCustomer Menu\n\t1 - View Inventory\n" + "\t2 - Add computer to your cart\n" + "\t3 - View Cart\n"
				+ "\t4 - View money in wallet\n" + "\t5 - Checkout \n" + "\t6 - Quit Shopping App\n");
        System.out.print("Please enter in your selection: ");
	}

	private void currentInventory() {
		System.out.println(this.shelfInventory.toString());
	}

	private void addComputerToCart() {
		Computer foundComputer;
		String customerSKU;
		int amountToPurchase;
		System.out.print("Enter in the Computer SKU to purchase: ");
		customerSKU = this.scan.nextLine();
		this.shelfInventory.findComputer(customerSKU);
		if (this.shelfInventory.findComputer(customerSKU) == null) {
			System.out.println("That computer SKU cannot be found here");
			return;
		}
		foundComputer = this.shelfInventory.findComputer(customerSKU);
		System.out.print("How many " + customerSKU + " computer(s) do you wish to purchase: ");
		amountToPurchase = Integer.parseInt(this.scan.nextLine());
		System.out.println("");
		if (foundComputer.getInventory() < amountToPurchase) {
			System.out.println("The store does not have that many " + customerSKU + " computers to sell");
		} else if (this.customer.enoughMoneyToBuy(foundComputer, amountToPurchase)) {
			this.customer.addComputer(foundComputer, amountToPurchase);
			System.out.println("You have added " + amountToPurchase + " " + customerSKU + " to your cart");
			System.out.println("You have " + this.customer.checkWallet() + " left to spend");
		} else {
			System.out.println("You do not have enough money in your wallet for this purchase");
		}
		
	}

	private void checkCart() {
	    System.out.println("The cart contains ");
		System.out.print(this.customer.getCart());
	}

	private void checkCustomerWallet() {
		System.out.print(" You have $");
		System.out.printf("%.2f", this.customer.checkWallet());
		System.out.println(" left to spend");
	}

	private void checkoutCustomer() {
		this.customer.completePurchase();
		System.out.println("You have checked out");
		this.checkCart();
	}
	
	private void exitMessage() {
		System.out.println("Thank you for using Computer Inventory Management\n");
	}

}
