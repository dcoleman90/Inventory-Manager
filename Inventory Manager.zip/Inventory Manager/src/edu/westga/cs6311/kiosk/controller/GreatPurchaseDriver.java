package edu.westga.cs6311.kiosk.controller;

import edu.westga.cs6311.kiosk.model.InventoryManager;
import edu.westga.cs6311.kiosk.view.KioskTUI;

/**This is the driver class 
 * It has the main method which drives the menuTUI
 * @author Drew Coleman
 * @version 12/02/2017
 *
 */
public class GreatPurchaseDriver {

	/**This is the main method
	 * @param args is the argument
	 */
	public static void main(String[] args) {
		InventoryManager storeInventory = new InventoryManager();
		KioskTUI menuTUI = new KioskTUI(storeInventory);
		menuTUI.runKiosk();
	}
}
